//"use strict";

var prefs = function () {
    page.call(this, "prefs");
    this.userData = {};
    this.localPG = null;
    var data = this.getPageData();
    setSwipe(data.swipeVal);
}

prefs.prototype = Object.create(page.prototype);
prefs.prototype.constructor = prefs;

prefs.prototype.update = function(show, state) {
    if(!show) {
    }
    else {
        var data = this.getPageData();
        // pages
        var s = '<label for="new_pages">Show Tools:</label>';
        s += '<select id="new_pages" class="needsclick" data-native-menu="false" multiple="multiple">\n';
        s += '<option data-placeholder="true">Show tools...</option>\n';
        var allPages = pg.allPages;
        for(var i=1; i<allPages.length; i++) {
            if((allPages[i]!="map" && allPages[i]!="chart") || data.debug) { // don't show map/chart unless we are debugging
                s += "<option value='"+ allPages[i] +"' ";
                if(pg.pages.indexOf(allPages[i]) != -1)
                    s += 'selected="selected" ';
                s += ">"+ allPages[i] +"</option>\n";            
            }
        }
        s += "</select>\n";
        $("#page_select").html(s);
        $("#page_select").trigger("create");
        //$("#new_pages").selectmenu("refresh", true);
        //$("#new_pages").listview("refresh");

        // categories
        dispCategories = pg.categories.concat(Array());
        //dispCategories.pop();     // remove "*"
        dispCategories.shift();   // remove "Uncateogrized"
        $("#new_categories").val(dispCategories.join(" "));

        // swipe
        if(pgUtil.isWebBrowser())
            $("#swipeDiv").hide();
        else
            $("#swipeSlider").val(data.swipeVal);

        // public access and debug
        $("#debug").prop('checked', data.debug).checkboxradio("refresh");
        //$("#publicAccess").prop('checked', data.publicAccess).checkboxradio("refresh");
        $("#wifiOnly").prop('checked', data.wifiOnly).checkboxradio("refresh");
        $("#screenTaps").prop('checked', data.screenTaps).checkboxradio("refresh");
        $("#perCategorySettings").prop('checked', data.perCategorySettings).checkboxradio("refresh");
	    this.resize();
    }
};

prefs.prototype.resize = function() {
    this.scrollableResize();
};

prefs.prototype.getPageData = function() {
    var data = pg.getUserData();
    // Defaults are set in the PG.
    return data;
};
prefs.prototype.submitSettings = function(doClose) {
    var data = this.getPageData();
    var pages = $("#new_pages").val();
    pages.unshift("home");
    var cat = $("#new_categories")[0].value.split(" ");
    var categories = new Array("Uncategorized");
    for(var i=0; i<cat.length; i++) {
        if(cat[i].trim() != "" &&
           categories.indexOf(cat[i]) == -1)
            categories.push(cat[i]);
    }
    //categories.push("*");
    var swipeVal = data.swipeVal;
    if(! pgUtil.isWebBrowser()) {
        swipeVal = parseInt($("#swipeSlider")[0].value);
        setSwipe(swipeVal);
    }

    this.userData = {
        'swipeVal': swipeVal,
        'debug': $("#debug")[0].checked ? 1 : 0,
        //'publicAccess': $("#publicAccess")[0].checked ? 1 : 0,
        'wifiOnly': $("#wifiOnly")[0].checked ? true : false,
        'screenTaps': $("#screenTaps")[0].checked ? true : false,
        'perCategorySettings': $("#perCategorySettings")[0].checked ? true : false
    };

    // no-op if settings have not changed
    if(pgUtil.equal(data, this.userData) &&
       pg.equal(pg.pages, pages)         &&
       pg.equal(pg.categories, cateogries)) {
        if(doClose)
            gotoPage(pg.page(), true);
        return;
    }
    this.localPG = new PG();
    this.localPG.init();
    this.localPG.copy(pg, false);
    this.localPG.setUserData(this.userData);
    this.localPG.setCategories(categories);
    this.localPG.setPages(pages);

    updateNavbar(pages, categories.length);

    if(pg.loggedIn) {
        PGEN.updateSettings( this.localPG, this.settingsUpdateComplete.bind(this,doClose) );
    }
    else {
        this.settingsUpdateComplete(doClose, true);
    }
};

prefs.prototype.settingsUpdateComplete = function(doClose, success) {
    var page = pg.page();
    var pagesEqual = pgUtil.equal(this.localPG.pages, pg.pages);
    var categoriesEqual = pgUtil.equal(this.localPG.categories, pg.categories);
    pg.copy(this.localPG, false);
    PGEN.writePG(pg);
    if(!pagesEqual || !categoriesEqual) {
        for(i=0; i<pg.pages.length; i++)
            PGEN.generatePage(pg.pages[i]);
    }
    // show an alert if changing the server settings was not successful.
    if(! success) {
        showAlert("Could not update data on server", "Warning");
    }
    if(doClose) {
        var pageIndex = pg.pages.indexOf(page);
        if(pageIndex < 0)
            pageIndex = 0;
        gotoPage(pg.pages[pageIndex], true);
    }
    updateSubheader(true);
};

UI.prefs = new prefs();
//# sourceURL=prefs.js
