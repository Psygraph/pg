
function note() {
    page.call(this, "note");
    this.recording = false;
    this.initialized = false;
    this.lastText = new Array();
}

note.prototype = Object.create(page.prototype);
note.prototype.constructor = note;


note.prototype.update = function(show, state) {
    if(!show) {
        this.lastText[pg.category()] = {'title': $("#noteTitle")[0].value,
                                        'text':  $("#noteText")[0].value};
        if(this.recording)
            this.annotate(); // stop recording if we leave the page.
        return {lastText: this.lastText};
    }
    if(typeof(state)!="undefined")
        this.lastText = state.lastText;
    if(!this.initialized) {
        $('#note_stop').hide();
        $('#note_start').show();
        this.initialized = true;
    }
    var s = {'title':""};
    if(typeof(this.lastText[pg.category()])!="undefined")
        s = this.lastText[pg.category()];
    else {
        var e = pg.mostRecentEvent(pg.category(),"note");
        if(e)
            s = e.data;
    }
    $("#noteTitle")[0].value = s.title;
    if(typeof(s.text)=="undefined")
        s.text = "";
    $("#noteText")[0].value = s.text;
    this.resize();
}

note.prototype.settings = function() {
    if(arguments.length) {
        var data = this.getPageData();
        s = "<div class='ui-field-contain no-field-separator' data-role='controlgroup'>";
        s += "<legend>Add data:</legend>";
        s += printCheckbox("note_addAudio",    "Audio",    data['addAudio']);
        //s += printCheckbox("note_addPicture",  "Picture",  data['addPicture']);
        s += printCheckbox("note_addPosition", "Position", data['addPosition']);
        s += "</div>";
        $("#page_settings").html(s);
    }
    else {
        return { addAudio:    $("#note_addAudio")[0].checked,
                 addPicture:  false, //$("#note_addPicture")[0].checked,
                 addPosition: $("#note_addPosition")[0].checked
               };
    }
}

note.prototype.getPageData = function() {
    var data = pg.getPageData("note", pg.category());
    if(! ('addAudio' in data))
        data.addAudio = false;
    if(! ('addPicture' in data))
        data.addPicture = false;
    if(! ('addPosition' in data))
        data.addPosition = false;
    return data;
}

note.prototype.endNote = function() {
    // hide the stop button
    $('#note_stop').hide();
    $('#note_start').show();
}

note.prototype.lever = function(arg) {
    if(arg=="right") {
        this.annotate();
    }
};

note.prototype.annotate = function() {
    if(this.recording) {
        pgAudio.stopRecord();
        this.recording = false;
        return;
    }
    // toggle the status
    $('#note_start').hide();
    $('#note_stop').show();


    var time          = pgUtil.getCurrentTime();
    var noteTitle     = $("#noteTitle")[0].value;
    var noteText      = $("#noteText")[0].value;
    var cat           = pg.category();
    var page          = pg.page();
    var eventData     = {'title': noteTitle};
    if(noteText != "")
        eventData.text = noteText;
    var eid           = pg.uniqueEventID();
    var audioFilename = pgAudio.getRecordFilename(eid);

    // logic here to wait for both position and audio to complete.
    var posReady   = $.Deferred();
    var audioReady = $.Deferred();
    $.when(posReady, audioReady).then(addEvent);

    var data = this.getPageData();
    if(data['addPosition']) {
        pgPosition.getCurrentPosition(posCB);
    }
    else {
        posReady.resolve();
    }

    if(data['addAudio']) {
        pgAudio.record(audioCB, audioFilename);
        this.recording = true;
    }
    else {
        audioReady.resolve();
    }

    function posCB(path) {
        if(path) {
            var lat = path[path.length-1][1];
            var lng = path[path.length-1][2];
            var alt = path[path.length-1][3];
            eventData.position = [pgUtil.getCurrentTime(), lat, lng, alt];
        }
        posReady.resolve();
    }
    function audioCB(success, meter) {
        if(typeof(meter)!="undefined") {
            // display metering information
            $('#note_stop').fadeTo(meter.sec, 0.4 + 0.6*meter.max);
            return;
        }
        if(success) {
            eventData.audio = pgAudio.getAudioExt();
        }
        $('#note_stop').css('opacity', '1');
        audioReady.resolve();
    }
    function addEvent() {
        // flash red so the user knows they submitted something.
        if(!data['addAudio'] && !data['addPosition'])
            setTimeout(UI.note.endNote, 300);
        else
            UI.note.endNote();
        // this is called when other callbacks have completed
        pg.addNewEvents({ id:       eid,
                          time:     pgUtil.getCurrentTime(),
                          category: cat,
                          page:     page,
                          type:     "text",
                          data:     eventData
                        }, true);
        syncSoon();
    }
}
    
UI.note = new note();
//# sourceURL=note.js
