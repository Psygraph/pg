var page = function(name) {
    this.name = name;
};

page.prototype.constructor = page;

page.prototype.update = function(show) {
};

page.prototype.settings = function() {
};

page.prototype.categorySettings = function() {
    var category = pg.category();
    if(arguments.length) {
        var limit = 64;
        var data = pg.getCategoryData();

        var s = "";
        s += "<div class='ui-field-contain no-field-separator'>";
        s += "<label for='descEdit'>Description:</label>";
        s += "<input class='settings' type='text' id='descEdit' name='desc' value='" + data.description +"' />";
        s += "</div>";

        s += "<div class='ui-field-contain no-field-separator'>";
        s += addEditButton("Style", "styleEdit");
        var text = data.style;
        if(data.style.length > limit) {
            this.src[pg.category()].styleEdit = data.style;
            text = data.style.substring(0,limit) + " ...";
        }
        // "bigText.css",
        var strings = ["default.css","aqua.css","black.css","dkgrey.css","grey.css","inverse.css","lime.css","ltblue.css","ltgreen.css","ltgrey.css","ltltgrey.css","ltpurple.css","orange.css","pink.css","steelblue.css","violet.css","white.css","yellow.css"];
        s += displaySelect("styleEdit", strings);
        //s += "<input class='settings' type='text' id='styleEdit' name='style' value='" + text +"' />";
        s += "</div>";

        // ### sound ###
        s += "<div class='ui-field-contain no-field-separator'>";
        s += addEditButton("Sound", "soundEdit");
        text = data.sound;
        if(data.sound.length > limit) {
            this.src[category].soundEdit = data.sound;
            text = data.sound.substring(0,limit) + " ...";
        }
        strings = ["default.mp3","alarm.mp3","bell.mp3","bike.mp3","birds.mp3","crickets.mp3","singingBowl.mp3"];
        s += displaySelect("soundEdit", strings);
        //s += "<input class='settings' type='text' id='soundEdit' name='style' value='" + text +"' />";
        s += "</div>";

        // ### text ###
        s += "<div class='ui-field-contain no-field-separator'>";
        s += addEditButton("Text", "textEdit");
        text = data.text;
        if(data.text.length > limit) {
            this.src[category].textEdit = data.text;
            text = data.text.substring(0,limit) + " ...";
        }
        strings = ["default.xml","einstein.xml","lojong.xml","null.xml","twain.xml","zen.xml"];
        s += displaySelect("textEdit", strings);
        //s += "<input class='settings' type='text' id='textEdit' name='style' value='" + text +"' />";
        s += "</div>";

        $("#category_settings").html(s);
        $("#category_settings").trigger("create");
    }
    else {
        var newCatData = {
            'description': $("#descEdit")[0].value,
            'style':       $("#styleEdit")[0].value,
            'sound':       $("#soundEdit")[0].value,
            'text':        $("#textEdit")[0].value
        };
        // If they have selected files without the data: URI scheme,
        // removed our cached values.
        if(newCatData.style.substring(0,5) != "data:")
            delete UI.settings.src[category].styleEdit;
        if(newCatData.sound.substring(0,5) != "data:")
            delete UI.settings.src[category].soundEdit;
        if(newCatData.text.substring(0,5) != "data:")
            delete UI.settings.src[category].textEdit;
        // if those values were stored as encoded files, se those values
        if(typeof(UI.settings.src[category].styleEdit)!="undefined")
            newCatData.style = UI.settings.src[category].styleEdit;
        if(typeof(UI.settings.src[category].soundEdit)!="undefined")
            newCatData.sound = UI.settings.src[category].soundEdit;
        if(typeof(UI.settings.src[category].textEdit)!="undefined")
            newCatData.text  = UI.settings.src[category].textEdit;
        return newCatData;
    }
    function addEditButton(name, field) {
        if(pgUtil.isWebBrowser()) { // this will only open a picture dialog on iOS
            var onclick = ' onclick="UI.page.getBase64File(\''+field+'\');" ';
            name = '<a href="" ' +onclick+ '>'+name+'</a>';
        }
        return "<label for='"+field+"'>"+name+":</label>";
    }
    function displaySelect(id, strings) {
        var s = "  <select id='"+id+"' value='"+id+"' title='"+id+"' data-native-menu='false'>";
        var displayed = false;
        for (var i=0; i<strings.length; i++) {
            if(text == strings[i]) {
                s += "    <option selected value='"+text+"'>"+text+"</option>";
                displayed = true;
            }
            else
                s += "    <option value='"+strings[i]+"'>"+strings[i]+"</option>";
        }
        if(!displayed)
            s += "    <option selected value='"+text+"'>"+text+"</option>";
        s += "  </select>";
        return s;
    }
};

page.prototype.getBase64File = function(id) {
    //var dlg = printCheckbox("encode", "Encode", false) + "<br/>";
    // $("#encode").prop('checked')
    var dlg = '<input id="fileEncoder" type="file" onchange="UI.page.encodeFile()"></input></br>';
    showDialog(
        {title: "File encoder", true: "OK", false: "Cancel"},
        dlg,
        function(){UI.page.encodeFile(id, $('#fileEncoder')[0].files[0], true);}
    );
};
page.prototype.encodeFile = function (id, file, encode) {
    var reader  = new FileReader();
    reader.onloadend = function () {
        var txt = "" + reader.result;
        //$("#"+id).attr('src',txt);
        var category = pg.category();
        UI.settings.src[category][id] = txt;
    }
    if(file) {
        $("#"+id).val("data:"+file.name);
        UI.settings.preventRefresh = true; //closing the dialog would generally refresh our data.

        if(encode) {
            reader.readAsDataURL(file);
        }
    }
};

page.prototype.resize = function() {
    var head   = $("#" + this.name + "_header").outerHeight(true);
    var foot   = 0;//$("#" + this.name + "_footer").outerHeight(true);
    var height = $(window).height() - (head+foot);
    var width  = $(window).width();
    $("#"+this.name).height(height);
};
page.prototype.scrollableResize = function() {
    var head   = $("#" + this.name + "_header").outerHeight(true);
    var foot   = 0;//$("#" + this.name + "_footer").outerHeight(true);
    // var kbdHeight = UI.window.kbdHeight;
    // window.innerHeight
    var height = $(window).height();
    var width  = $(window).width();
    var totalHeight = head;
    $("#"+this.name+"Div").children().each(function(){
        totalHeight = totalHeight + $(this).outerHeight(true);
    });
    $("#"+this.name+"Div").height(Math.max(totalHeight, height));
};

page.prototype.getPageData = function() {
    var data = pg.getPageData(this.name, pg.category());
    return data;
};

page.prototype.displayEventData = function(e) {
    var txt = "";
    var dur = getTimeString(e.duration);
    if((e.page=="stopwatch" || e.page=="map") &&
       (e.type=="interval")) {
        txt += dur;
        if(typeof(e.data.position)!="undefined")
            txt += " +geo";
        if(typeof(e.data.acceleration)!="undefined")
            txt += " +acc";
        if(typeof(e.data.rotation)!="undefined")
            txt += " +rot";
        if(typeof(e.data.pathLength)!="undefined")
            txt += " " + e.data.pathLength.toFixed(2) + " miles";
    }
    else if(e.page=="stopwatch" && e.type=="reset") {
        // resets have nothing to display
    }
    else if(e.page == "note" ||
            (e.page == "map" && e.type == "marker") ) {
        txt += pgUtil.escape(e.data.title);
        if(typeof(e.data.text)!="undefined") {
            title = e.data.title != "" ? e.data.title : "note";
            txt += alertTextHref("+text", e.data.title, e.data.text);
        }
        if(typeof(e.data.position)!="undefined") {
            var ll = "lat: " + e.data.position[1].toFixed(4) + ", long: " + e.data.position[2].toFixed(4);
            txt += alertTextHref("+pos", e.data.title, ll);
        }
        if(typeof(e.data.audio)!="undefined") {
            var fn  = pgAudio.getRecordFilename(e.id, e.data.audio);
            var id  = e.id;
            var tag = playMediaHref("+audio", id, fn);
            txt += tag;
        }
    }
    else if(e.page == "timer") {
        if(e.type=="interval")
            txt += dur;
        else if(e.type=="reset") {
            if(typeof(e.data.resetTime)!="undefined")
                txt += " " + getTimeString(e.data.resetTime);
        }
    }
    else if(e.page == "counter") {
        txt += e.data.count;
        if(e.type=="reset" && e.data.target != 0) {
            if(e.data.count == e.data.target)
                txt += ", correct";
            else
                txt += ", incorrect";
        }
    }
    else if(e.page == "home") {
        try {
            // login and logout events... nothing to display.
            if(e.type=="error" ||
               e.type=="warn"  ||
               e.type=="log")
                txt += alertTextHref("+text", e.type, e.data.text);
        } catch(e) {}
    }
    else
        console.log("unknown page for event, type: " + e.page + e.type);
    txt += "";
    return txt;

    function alertTextHref(type, title, text) {
        var txt = ' <a href="" onclick="showAlert(\''+pgUtil.escape(text, true)+'\', \''+pgUtil.escape(title, true)+'\'); return true;" >'+type+'</a>';
        return txt;
    }
    function playMediaHref(type, id, fn) {
        var txt = ' <a href="" onclick="return pgAudio.playRecorded(\''+id+'\', \''+fn+'\');">'+type+'</a>';
        return txt;
    }
    function getTimeString(dur) {
        return pgUtil.getStringFromMS(dur) + " sec";
    }
};

UI.page = new page();
//# sourceURL=page.js
