
function timer() {
    page.call(this, "timer");
    this.clock       = null;
    this.startTime   = {};
}

timer.prototype = Object.create(page.prototype);
timer.prototype.constructor = timer;

timer.prototype.update = function(show, state) {
    var category = pg.category();
    if(!show) {
        this.clock.stop();
        var notifyState = pgNotify.state();
        //showLog("Storing startTime: " + pgUtil.getStringFromMS(this.startTime.Uncategorized) );
        return {'startTime': this.startTime, 'notifyState': notifyState };
    }
    //showLog("startTime: " + pgUtil.getStringFromMS(this.startTime.Uncategorized) );
    if(typeof(state) != "undefined") {
        this.startTime = state.startTime;
        //showLog("Restoring startTime: " + pgUtil.getStringFromMS(this.startTime.Uncategorized) );
        pgNotify.state(state.notifyState);
    }
    var initializing = ! this.clock;
    if(initializing) {
        this.timerWidget = document.getElementById('countdown_timer');
        this.startWidget = document.getElementById('countdown_start');
        var e = this.getElapsedTimer(category);
        this.startWidget.value = pgUtil.getStringFromMS(e.countdownTime);
        this.clock  = new Clock(this.timerCallback.bind(this), 50, function(a,b,c){});
    }
    pgNotify.setCallback(this.notificationCallback.bind(this));
    
    for(var i=0; i<pg.categories.length; i++) {
        var cat = pg.categories[i];
        var running = this.running(cat);
        pgNotify.callElapsed(cat, running, initializing);
    }
    
    this.refreshTimer(category);
    // xxx it would be nice to have a complete state reset somewhere...
    //pgNotify.removeAll()
    this.resize();
};

timer.prototype.refreshTimer = function(category) {
    category = (typeof(category) != "undefined") ? category : pg.category();
    var data = this.getPageData();
    var e = this.getElapsedTimer(category);
    if(data.timerType == "stopwatch") {
        //this.startWidget.value = pgUtil.getStringFromMS(0);
        if(e.running == 1) {
            this.clock.startFromTime(e.startTime);
        }
        else {
            this.clock.setElapsedMS(e.duration);
        }
        $("#countdown_start").hide();
    }
    else if(data.timerType == "countdown") {
        //this.startWidget.value = pgUtil.getStringFromMS(e.countdownTime);
        this.clock.setCountdown(e.countdownTime, false);
        if(e.running == 1) {
            this.clock.startFromTime(e.startTime);
        }
        else {
            this.clock.setElapsedMS(e.duration);
        }
        $("#countdown_start").show();
    }
    else if(data.timerType == "countup") {
        //this.startWidget.value = pgUtil.getStringFromMS(e.countdownTime);
        this.clock.setCountdown(e.countdownTime, true);
        if(e.running == 1) {
            this.clock.startFromTime(e.startTime);
        }
        else {
            this.clock.setElapsedMS(e.duration);
        }
        $("#countdown_start").show();
    }
    if(e.running == 1) {
        $('#timer_start').hide();
        $('#timer_stop').show();
    } else {
        $('#timer_start').show();
        $('#timer_stop').hide();
    }
};

timer.prototype.settings = function() {
    if(arguments.length) {
        var data = this.getPageData();
        s  = "<div class='ui-field-contain no-field-separator'>";
        s += "  <label for='timerType'>Timer type:</label>";
        s += "  <select id='timerType' value='Select type' title='Select type' data-native-menu='false'>";
        //s += "    <option value='stopwatch'>stopwatch</option>";
        s += "    <option value='countdown'>countdown</option>";
        s += "    <option value='countup'>countup</option>";
        s += "  </select>";
        s += "</div>";
        s += "<div class='ui-field-contain no-field-separator'>";
        s += "  <label for='timerAlarm'>Timer alarm:</label>";
        s += "  <select id='timerAlarm' value='Timer alarm' title='Timer alarm' data-native-menu='false'>";
        s += "    <option value='none'>none</option>";
        s += "    <option value='text'>text</option>";
        s += "    <option value='sound'>sound</option>";
        s += "    <option value='both'>both</option>";
        s += "  </select>";
        s += "</div>";
        s += "<div class='ui-field-contain no-field-separator' data-role='controlgroup'>";
        s += "<legend>Loop:</legend>";
        s += printCheckbox("loop", "Loop", data['loop']);
        s += "</div>";
        s += "<div class='ui-field-contain no-field-separator'>";
        s += "  <label for='countdownTime'>Countdown Time (s):</label>";
        var val = pgUtil.getStringFromMS(data.countdownTime);
        s += "  <input class='settings' type='text' id='countdownTime' value='"+val+"'/>";
        s += "</div>";
        s += "<div class='ui-field-contain no-field-separator'>";
        s += "  <label for='maxResetValue'>Random interval (s):</label>";
        val = pgUtil.getStringFromMS(data.randomInterval);
        s += "  <input class='settings' type='text' id='randomInterval' value='"+val+"'/>";
        s += "</div>";

        $("#page_settings").html(s);
        $("#timerType").val(data.timerType).change();
        $("#timerAlarm")[0].value = data.timerAlarm;
    }
    else {
        this.refreshTimer();
        var data = {
            timerType:      $("#timerType").val(),
            timerAlarm:     $("#timerAlarm")[0].value,
            loop:           $("#loop")[0].checked,
            countdownTime:  pgUtil.getMSFromString($("#countdownTime").val()),
            randomInterval: pgUtil.getMSFromString($("#randomInterval").val())
        }
        var countdownTime = Math.floor(data.countdownTime + data.randomInterval * Math.random() );
        this.startWidget.value = pgUtil.getStringFromMS(countdownTime);
        return data;
    }
};

//timer.prototype.changeCountdownValue = function(value) {
//var data = this.getPageData();
//data.countdownTime = value;//this.startWidget.value;
// no way to update this value xxx
//this.setPageData(data);
//}
timer.prototype.running = function(cat) {
    //return this.clock.running();
    return this.startTime.hasOwnProperty(cat) && (this.startTime[cat] > 0);
};
    
timer.prototype.getPageData = function(category) {
    category = (typeof(category) != "undefined") ? category : pg.category();
    var data = pg.getPageData("timer", category);
    if(! ('timerType' in data))
	data.timerType      = "countdown";
    if(! ('timerAlarm' in data))
	data.timerAlarm     = "sound";
    if(! ('loop' in data))
	data.loop           = 0;
    if(! ('countdownTime' in data))
	data.countdownTime  = 60*1000;
    if(! ('randomInterval' in data))
	data.randomInterval = 0;
    return data;
};

timer.prototype.lever = function(arg) {
    if(arg=="left") {
        this.reset(pg.category(), false);
    }
    else if(arg=="right") {
        this.startStop();
    }
};

timer.prototype.getNotificationOpts = function(category, atTime) {
    var catData  = pg.getCategoryData(category);
    var pageData = this.getPageData(category);
    var txt      = pg.getCategoryText(category);
    var len      = txt.text.length;
    var opts = {
        "sound":    "",
        "at":       new Date(atTime),
        "data":     {"category": category, "time": atTime}
    };
    if(category == "Uncategorized") {
        opts.title      = " ";
        opts.data.title = " ";
    }
    else {
        opts.title      = txt.title;
        opts.data.title = txt.title;
    }
    if(pageData.timerAlarm=="sound" || pageData.timerAlarm=="both") {
        opts.sound = pgAudio.getCategorySound(category, true);  
        // We should play the sound ourselves if we want to turn it off by shaking.
    }
    if(pageData.timerAlarm=="text" || pageData.timerAlarm=="both") {
        if(len) {
            var text = txt.text[pgUtil.randomInt(0,len-1)];
            // should the following happen only on IOS?
            var re = new RegExp("<br/>", "g");
            text = text.replace(re, "\n");
            opts.text = text;
            opts.data.text = text;
        }
    }
    return opts;
};

timer.prototype.setNotification = function(category, atTime) {
    if(atTime < pgUtil.getCurrentTime()) {
        atTime = pgUtil.getCurrentTime() + 200;
        showLog("Error: notification scheduled in the past.");
    }
    var opts = this.getNotificationOpts(category, atTime);

    pgNotify.add(category, opts);
    showLog("Set "+category+" notification for: " + atTime);
};

timer.prototype.unsetNotification = function(category) {
    pgNotify.remove( category );
    showLog("Unset "+category+" notification.");
};

timer.prototype.notificationCallback = function(data) {
    // remove the notification. This allows our app to play sound and display text.
    showLog("Received "+data.category+" notification callback at: " + pgUtil.getCurrentTime() + " with time : " + data.time);
    if(data.time != 0) {
        this.reset(data.category, true, data);
    }
    else {
        // There was no notification, but perhaps there should have been.
        // Call reset anyway to restart the clock.
        if(this.running(data.category)) {
            this.startStop(data.category);
        }
        //this.reset(data.category, false);
        this.refreshTimer();
    }
};

timer.prototype.timerCallback = function(str) {
    this.timerWidget.value = str;
};

timer.prototype.startStop = function(category, time) {
    category = (typeof(category) != "undefined") ? category : pg.category();
    time = (typeof(time) != "undefined") ? time : pgUtil.getCurrentTime();
    var currentPage = pg.page()=="timer" && pg.category()==category;
    if(!this.running(category)) {
        var data = this.getPageData(category);
        var timerMsec = pgUtil.getMSFromString(this.timerWidget.value);
        var startMsec = pgUtil.getMSFromString(this.startWidget.value);
        if((data.timerType=="countdown" && timerMsec==0) ||
           (data.timerType=="countup"   && timerMsec>=startMsec))
            this.reset(category, false);
        startMsec = pgUtil.getMSFromString(this.startWidget.value);
        if(startMsec==0)
            return;  // there is no zero-length countdown.
        this.clock.start();
        $('#timer_start').hide();
        $('#timer_stop').show();
        this.startTime[category] = time;
        var remaining = this.clock.remaining();
        // Set a notification.
        // This may mean that both the timer and the notification attempt to trigger the Reset()
        this.setNotification(category, time + remaining);
    }
    else {
        this.unsetNotification(category);
        this.clock.stop();
        $('#timer_start').show();
        $('#timer_stop').hide();
        pg.addNewEvents({'page': "timer",
                    'type': "interval",
                    'start': this.startTime[category],
                    'duration': time - this.startTime[category],
                    }, true);
        this.startTime[category] = 0;
        this.refreshTimer(category);
        this.unsetNotification(category);
    }
    syncSoon();
    return false;
};

timer.prototype.reset = function(category, complete, notification) {
    var isNotification = (typeof(notification) != "undefined") ? true : false;
    var time           = pgUtil.getCurrentTime();
    var currentPage    = (pg.page()=="timer") && (pg.category()==category);
    var data           = this.getPageData(category);
    var newInterval    = pgUtil.getMSFromString(this.startWidget.value);
    var finished       = complete && data.loop==0;

    // add the new event
    if(complete) {
        //var countdownTime = pgUtil.getMSFromString(this.startWidget.value);
        newInterval = Math.floor(data.countdownTime + data.randomInterval * Math.random() );
        this.startWidget.value = pgUtil.getStringFromMS(newInterval);
    }
    var edata = {'resetTime': newInterval, 'complete': complete};
    pg.addNewEvents({'page': "timer", 'type': "reset", 'category': category, 'start': time, 'data': edata}, true);
    
    // trigger startStop if we have finished
    if(finished) {
        // set the start time, execute the alarm.
        if(this.running(category))
            this.startStop(category, time); // notification.time
        if(currentPage)
            this.refreshTimer();
    }
    else {
        // If we are called from the pgNotify callback, reschedule
        if(newInterval) {
            if(complete) {
                if(isNotification) {
                    // Use the notification time if it is approximately correct
                    // in order to remove any jitter when the app is running.
                    //if(Math.abs(time-notification.time) < 400)
                    //    time = notification.time;
                    this.setNotification(category, time + newInterval);
		}
            }
            else {
                if(this.running(category)) {
                    this.unsetNotification(category);
                    this.setNotification(category, time + newInterval);
		}
            }
        }
        
        // if this is the current page, update the clock
        if(currentPage) {
            this.refreshTimer();
            //this.startWidget.value = pgUtil.getStringFromMS(newInterval);
            //this.clock.setCountdown(newInterval, data.timerType=="countup");
            //this.clock.reset();
            //if(data.timerType == "countup")
            //    this.timerWidget.value = pgUtil.getStringFromMS(0);
            //else
            //    this.timerWidget.value = this.startWidget.value;
        }
    }
    // execute the alarm.
    if(complete && isNotification)
        this.alarm(category, notification);
    syncSoon();
    return false;
};

timer.prototype.alarm = function(category, opts) {
    var data = this.getPageData(category);
    if(opts.alarm) {
        if(opts.elapsed==false)
            opts = this.getNotificationOpts(category, 0);
        if((data.timerAlarm=="text" || data.timerAlarm=="both") &&
           category==pg.category()) {
            if(opts.text!="undefined") {
                showAlert(opts.text, opts.title);
            }
        }
    }
    // sound the alarm, since the app will close the notification and silence the alarm.
    if(data.timerAlarm=="sound" || data.timerAlarm=="both") {
        // sound the alarm!
        var idx = pgAudio.alarm(category);
        // allow the alarm to be turned off by changing pages
        setPageChangeCallback(function(){pgAudio.stopAlarm(idx)});
    }
};

timer.prototype.getElapsedTimer = function(category) {
    var e              = pg.getEventsInPage("timer", category);
    var startTime      = 0;
    if(this.startTime.hasOwnProperty(category))
        startTime = this.startTime[category];
    var running        = startTime != 0;
    var data           = this.getPageData(category);
    //var countdownTime  = data.countdownTime;
    var countdownTime  = Math.floor(data.countdownTime + data.randomInterval * Math.random() );
    var duration       = 0.0;
    var resetTime      = 0.0;

    if(running) {
	var elapsedTime = 0.0;
	for(var i=0; i<e.length; i++) {
	    var event = pgUtil.parseEvent(e[i]);
	    if(event.type=="interval") {
		var eventStartTime = event.start;
		var eventDuration  = event.duration;
		var eventStopTime  = event.start + event.duration;
		if(resetTime) {
		    if(eventStopTime > resetTime) {
			elapsedTime += (eventStopTime-resetTime);
		    }
		    break;
		}
		else
		    elapsedTime += event.duration;
	    }
	    else if(event.type == "reset") {
		if(resetTime == 0) {
		    countdownTime = parseInt(event.data.resetTime);
		    resetTime     = event.start;
		}
		if(event.start > startTime) {
		    startTime = event.start;
		}
	    }
	}
	startTime   -= elapsedTime;
    }
    else {
	for(var i=0; i<e.length; i++) {
	    var event = pgUtil.parseEvent(e[i]);
	    if(event.type=="interval") {
		var eventStartTime = event.start;
		var eventDuration  = event.duration;
		var eventStopTime  = event.start + event.duration;
		if(resetTime) {
		    if(eventStopTime > resetTime) {
			// running at the time of the reset.
			if(eventStartTime > resetTime) {
			    // error in event order
			}
			// stopped at the time of reset
			duration += (eventStopTime-resetTime);
			//duration += (resetTime - eventStartTime);
		    }
		    break;
		}
		else
		    duration += event.duration;
	    }
	    else if(event.type == "reset") {
		if(!resetTime) {
		    countdownTime = parseInt(event.data.resetTime);
		    resetTime     = event.start;
		}
	    }
	}
    }
    // If we are running, the client should use the start time.
    // otherwise, the client should use the duration.
    var ans = {'countdownTime': countdownTime, 'startTime': startTime, 'duration': duration, 'running': running};
    return ans;
};

UI.timer = new timer();
//# sourceURL=timer.js
