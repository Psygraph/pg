
var home = function () {
    page.call(this, "home");
    this.username = "";
    this.cert     = "";
    this.server   = "";
    this.initialized = false;
    this.loggingIn   = false;
    this.askedForPW  = false;
};

home.prototype = Object.create(page.prototype);

home.prototype.constructor = home;

home.prototype.finishedLogin = function() {
    return this.initialized && !this.loggingIn;
};

home.prototype.update = function(show) {
    if(!this.initialized) {
        this.initialized = true;
        this.beginLogin(cb.bind(this));
    }
    else {
        this.status(pg.loggedIn);
    }
    if(show) {
        this.resize();
    }
    function cb() {
        if(WORDPRESS==true) {
            // these variables are all set if index.html is served by wp.php
            this.username = WP_USERNAME;
            this.cert     = WP_CERT;
            this.server   = WP_SERVER;
            PGEN.login(this.username, this.passwordCB.bind(this,""));
        }
        else {
            //$('#logout').hide();
            var data = this.getPageData();
            PGEN.readPG(this.localFileCB.bind(this));
        }
    }
};

home.prototype.beginLogin = function(callback) {
    startBusy();
    this.loggingIn = true;

    // If we find one of these files sitting around, we encountered a login error.
    // So we ask the user if they wish to reset the local files.
    var wait = $.Deferred();
    pgFile.readFile("com.psygraph.lastError", handleError);
    pgFile.readFile("com.psygraph.state",     handleState);
    $.when(wait).then(callback);

    function handleState(success, state) {
        if(success) {
            pgFile.deleteFile("com.psygraph.state");
            UI.state = state;
            pgAccel.update(true, UI.state.accel);
            pgPosition.update(true, UI.state.position);
        }
    }
    function handleError(success, event) {
        if(success) { // read the file
            pgFile.deleteFile("com.psygraph.lastError"); // try to handle once only
            showDialog({'title': event.data.title, true: "Delete", false: "Cancel"},
                       "<p>There was an uncaught error during the previous login: "+event.data.text+"</p>" +
                       "<p>Do you wish to delete the local data and settings?</p>",
                       cb);
        }
        else
            wait.resolve();
        function cb(success) {
            if(success) {
                pgFile.deleteFile("com.psygraph.pg");
                pgFile.deleteFile("com.psygraph.events");
                showLog("Error: Deleted PG on user request.");
                UI.home.logoutAndErase(cb2.bind(this, event));
            }
            else
                cb2(event);
        }
        function cb2(event) {
            pg.addNewEvents(event, true);
            // hopefully the home page is more stable...
            pg.pageIndex     = 0;
            pg.categoryIndex = 0;
            gotoLoadedPage("home");
            wait.resolve();
        }
    }
};
home.prototype.endLogin = function() {
    finishBusy();
    this.loggingIn = false;
    //pgFile.deleteFile("com.psygraph.lastError");
    if(navigator.splashscreen) {
        navigator.splashscreen.hide();
    }
    pgFile.readFile("com.psygraph.exit", handleExit);
    PGEN.readPsygraph(cb);
    function cb(success) {
        if(success) {
            gotoLoadedPage(pg.page());
        }
        else {
            gotoLoadedPage("help");
        }
    }
    function handleExit(success, event) {
        if(success) {
            pgFile.deleteFile("com.psygraph.exit");
            pg.addNewEvents(event, false);
        }
    }
};

home.prototype.settings = function(show) {
    if(arguments.length) {
        var data = this.getPageData();
        var s = "";

        //s += printCheckbox("home_stayOffline", "Stay offline", data['stayOffline']);
        s += '<div class="ui-field-contain no-field-separator" id="userDiv">';
        s += '  <label for="user">User:</label>';
        s += '  <input type="text" id="username" name="username" value=""/>';
        s += '</div>';
        s += '<div class="ui-field-contain no-field-separator" id="serverDiv">';
        s += '  <label for="server">Server:</label>';
        s += '  <input type="text" id="server" name="server" value="localhost" data-clear-btn="true" />';
        s += '</div>';

        if(pg.getUserDataValue("debug"))
            s += printCheckbox("home_createLoginEvents", "Create login events", data['createLoginEvents']);

        $("#page_settings").html(s);

        $("#username").val(pg.username);
        $('#username').prop('readonly', pg.loggedIn);

        var server = pg.server;
        if(server.indexOf("/wp-content") != -1)
            server = server.substr(0,server.indexOf("/wp-content"));
        $("#server").val(server);
        $('#server').prop('readonly', pg.loggedIn);
    }
    else {
        if(!pg.loggedIn) {
            pg.username = $("#username").val();
            pg.server   = $("#server").val();
        }
        var data = this.getPageData();
        if(pg.getUserDataValue("debug"))
            data.createLoginEvents = $("#home_createLoginEvents")[0].checked;
        return data;
    }
};

home.prototype.localFileCB = function(success, struct) {
    if(success) {
        this.username = struct.username;
        this.cert     = struct.cert;
        this.server   = struct.server;
        if(struct.certExpiration < pgUtil.getCurrentTime())
            this.cert = "";
        if(struct.loggedIn && pg.online) {
            PGEN.login(this.username, this.passwordCB.bind(this,""));
            return;
        }
    }
    PGEN.login(this.username, cb.bind(this));
    function cb(success) {
        pg.server    = this.server;
        pg.username  = this.username;
        pg.cert      = this.cert;
        this.endLogin();
    }
};

home.prototype.lever = function(arg) {
    //if(arg=="right") {
    //    this.loginUser();
    //}
};

home.prototype.loginUser = function() {
    //var data = this.getPageData();
    startBusy();
    this.username = pg.username;
    this.server   = pg.server;
    this.cert     = pg.cert;
    if(pg.loggedIn) {
        PGEN.logout(this.logoutCB.bind(this));
    }
    else {
        if(!pg.online) {
            showDialog({title: "Not online", true: "OK"},
                       "<p>This device is not currently online, please either connect or work in offline mode.</p>",
                       function(){});
            this.endLogin();
            return;
        }
        if(this.server == "" || this.username == "") {
            var server = (this.server!="") ? this.server : this.defaultServer();
            showDialog({title: "Specify login info", true: "OK", false: "Cancel"},
                       "<label for='username'>Username:</label>"+
                       "<input type='text'     id='dlg_username' name='username' value='"+this.username+"'/><br/>"+
                       "<p>Visit "+this.getServerLink(server)+" to create an account.</p><br/>",
                       cb.bind(this, server)
            );
        }
        else
            UI.home.verifyUser();
    }
    function cb(server, clickedOK) {
        if(!clickedOK) {
            gotoLoadedPage("home");
            return;
        }
        UI.home.username = $('#dlg_username')[0].value;
        UI.home.server   = server;//$('#dlg_server')[0].value;
        if(UI.home.username=="") {
            this.endLogin();
            showDialog({title: "Invalid username", true: "OK"},
                       "<p>Please choose a non-empty username.  This should correspond to your online username if you wish to synchonize your data.</p>");
            return;
        }
        UI.home.verifyUser();
    }
};

home.prototype.status = function(onlineStatus) {
    var server = (this.server!="") ? this.server : this.defaultServer();
    txt = "<br/>";
    txt += "<p class='banner'><img src='img/logo.png' height='108' width='108'></img></p>";
    if(!onlineStatus) { // offline
        //$('#logout').hide();
        //$('#login').show();
        //txt += "<p><b>username</b>: "+this.username+"</p>";
        //txt += "<p><b>server</b>:   "+this.getServerLink(server)+"</p>";
        //click = "onclick='UI.home.loginUser(); return true;'";
        //txt += "<p><ul>";
        //txt += "<li><b>status</b>:   offline (<a data-role='button' href='' "+click+">Login</a>)</li>";
        //txt += "</ul></p>";
    }
    else { // online
        //$('#login').hide();
        //$('#logout').show();
        txt += "<p><b>username</b>: "+this.username+"</p>";
        txt += "<p><b>server</b>:   "+this.getServerLink(server)+"</p>";
        click = "onclick='UI.home.loginUser(); return true;'";
        txt += "<p><ul>";
        txt += "<li><b>status</b>:    online (<a data-role='button' href='' "+click+">Logout</a>)</li>";
        var lastSync = "unknown.";
        if(pg.lastSync)
            lastSync = pgUtil.getDateString(pg.lastSync);
        txt += "<li><b>Last sync</b>: " +lastSync +"</li>";
        txt += "</ul></p>";
    }
    $("#home_status").html(txt);
}

home.prototype.getServerLink = function(server) {
    var serverURL = "http://" + pgUtil.extractDomain(server);
    return "<a href='' onClick='return pgUtil.openWeb(\""+serverURL+"\")'>"+serverURL+"</a>";
}

home.prototype.verifyUser = function() {
    //startBusy();
    //setTimeout(function(){
    PGEN.verifyUser(this.server, this.username, verifyUserCB.bind(this))
    //;}), 100);
    function verifyUserCB(err, server) {
        //finishBusy();
        server = (typeof(server)=="undefined" ? this.server : server);
        if(!err) {
            this.server = server;
            this.getPassword();
        }
        else {
            this.endLogin();
            if(err=="user") {
                showDialog({title: "Username failure", true: "OK"},
                           "<p>You appear not have an account at server:"+server+" with username:"+this.username+"<br/>" + 
                           ". Visit " +this.getServerLink(server),
                           function(){gotoLoadedPage("home")}
                );
            }
            else if(err=="server") {
                // OK, just show an error.
                showDialog({title: "Server failure", true: "OK"},
                           "<p>There was a problem contacting the server: "+server+"<br/>"+
                           "Please check your internet connection.</p>",
                           function(){gotoLoadedPage("home")}
                );
            }
            else {
                showLog("Error logging in: " + err);
            }
        }
    }
};

home.prototype.getPassword = function() {
    if(typeof(this.cert) != "undefined" && this.cert != "") {
        // we have the information we need, skip the dialog
        this.passwordCB("");
    }
    else {
        this.endLogin();
        this.askedForPW = true;
        var server = this.getServerLink(this.server);
        setTimeout(function() {
                showDialog({title: "Enter your password", true: "OK", false: "Cancel"},
                           "<p>"+server+"</p><input type='password' id='passw' name='password' value=''/>", cb
                )}, 100);
    }
    function cb(clickedOK) {
        if(!clickedOK) {
            $( ":mobile-pagecontainer" ).pagecontainer( "change", "#home");
            return;
        }
        var pass = $('#passw')[0].value;
        UI.home.passwordCB(pass);
    }
};

home.prototype.passwordCB = function(password) {
    pg.useServer = true;
    pg.server    = this.server;
    pg.username  = this.username;
    pg.cert      = this.cert;
    PGEN.serverLogin(password, this.loginCB.bind(this));
};

home.prototype.loginCB = function(success) {
    if(success) {
        this.username = pg.username;
        this.cert     = pg.cert;
        this.server   = pg.server;

        var data = this.getPageData();
        this.logEvent("login");
        this.status(true);
        gotoLoadedPage(pg.page());
    }
    else {
        this.status(false);
        this.cert = ""; // xxx
        if(this.askedForPW == false) {
            this.getPassword();
            return;
        }
        showDialog({title: "Login failure for "+this.username, true: "OK"},
                   "<p>If you need to register or recover your password, <br/>"+
                   "visit " + this.getServerLink(this.server) + "</p>",
                   function(){gotoLoadedPage("home")}
        );
    }
    this.endLogin();
};

home.prototype.logoutAndErase = function(callback) {
    callback = typeof(callback)!="undefined" ? callback : function(){};
    PGEN.logout(this.logoutCB.bind(this), true);
    pg.init();
    this.server   = "";
    this.username = "";
    this.cert     = "";
    gotoLoadedPage("home", true);
    callback();
};

home.prototype.getPageData = function() {
    var data = pg.getPageData("home", pg.category());
    if(! ('createLoginEvents' in data))
        data.createLoginEvents = false;
    //if(! ('stayOffline' in data))
    //    data.stayOffline = false;
    return data;
};

home.prototype.logoutCB = function(success) {
    if(success) {
        this.logEvent("logout");
    } else {
        showAlert("Logout failure");
    }
    this.status(false);
};

home.prototype.logEvent = function(type) {
    var data = this.getPageData();
    if(data.createLoginEvents) {
        var event = {page: "home",
                     type: type,
                     start: pgUtil.getCurrentTime(),
                     data: {}};
        if(type=="exit") // write a file for later.
            pgFile.writeFile("com.psygraph.exit", event);
        pg.addNewEvents(event, true);
    }
};

home.prototype.defaultServer = function() {
    var server = "https://psygraph.com";
    return server;
};


UI.home = new home();
//# sourceURL=home.js
