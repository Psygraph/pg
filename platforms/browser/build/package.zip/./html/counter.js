
var counter = function () {
    page.call(this, "counter");
    this.count = 0;
}

counter.prototype = Object.create(page.prototype);
counter.prototype.constructor = counter;

counter.prototype.update = function(show, state) {
    if(!show) {
        this.setShake("none");
        return {};
    }
    // nothing to do for state
    // show the last count in this category.
    var e = pg.mostRecentEvent(pg.category(), "counter");
    if(e) {
        this.count = e.data.count;
    }
    else {
        this.count = 0;
    }
    $("#counter_edit")[0].value = this.count;
    this.resize();
    var data = this.getPageData();
    this.setShake(data.shakeAlarm, data.shakeVal);
};

counter.prototype.settings = function() {
    var data = this.getPageData();
    if(arguments.length) {
        s = "<div class='ui-field-contain no-field-separator' data-role='controlgroup'>";
        if(!pgUtil.isWebBrowser()) {
            s += "<fieldset>";
            s += "<div class='ui-field-contain no-field-separator'>";
            s += "  <label for='shakeAlarm'>Shake alarm:</label>";
            s += "  <select id='shakeAlarm' value='Shake alarm' title='Shake alarm' data-native-menu='false'>";
            s += "    <option value='none'>none</option>";
            s += "    <option value='silent'>silent</option>";
            s += "    <option value='beep'>beep/buzz</option>";
            s += "    <option value='sound'>sound</option>";
            s += "  </select>";
            s += "</div>";
            s += "</fieldset>";

            s += "<fieldset>";
            s += "<label for='shakeSlider'>Shake sensitivity:</label>";
            s += "<input type='range' name='shakeSlider' id='shakeSlider' value='" + data.shakeVal + "' min='0' max='20' step='0.1'>";
            s += "</fieldset>";

        }

        s += "<fieldset>";
        s += "<label for='countTarget'>Count target:</label>";
        s += "<input type='range' name='countTarget' id='countTarget' value='" + data.countTarget + "' min='0' max='20' step='1'>";
        s += "</fieldset>";
        s += "</div>";
        $("#page_settings").html(s);
        if(!pgUtil.isWebBrowser())
            $("#shakeAlarm")[0].value = data.shakeAlarm;
    }
    else {
        data.countTarget = parseInt($("#countTarget")[0].value);
        if(! pgUtil.isWebBrowser()) {
            data.shakeAlarm  = $("#shakeAlarm")[0].value;
            data.shakeVal    = parseFloat($("#shakeSlider")[0].value);
        }
        return data;
    }
};

counter.prototype.setShake = function(alarm, val) {
    if(alarm != "none" && ! pgUtil.isWebBrowser()) {
        pgAccel.shake(this.onShake.bind(this), val, 2000);
        pgAccel.start();
    }
    else {
        pgAccel.stop();
    }
};

counter.prototype.onShake = function() {
    var data = this.getPageData();
    if(data.shakeAlarm=="beep") {
        pgAudio.beep();
    }
    else if(data.shakeAlarm=="sound") {
        var idx = pgAudio.alarm(false);
        setTimeout(pgAudio.stopAlarm.bind(idx),60);
    }
    else if(data.shakeAlarm=="silent") {
    }
    else {
        showLog("Error in shake callback");
    }
    this.startStop("shake");
};

counter.prototype.getPageData = function() {
    var data = pg.getPageData("counter", pg.category());
    if(! ('shakeAlarm' in data))
        data.shakeAlarm = "none";
    if(! ('shakeVal' in data))
        data.shakeVal = 6;
    if(! ('countTarget' in data))
        data.countTarget = 0;
    return data;
};

counter.prototype.lever = function(arg) {
    if(arg=="left") {
        this.reset();
    }
    else if(arg=="right") {
        this.startStop();
    }
};

counter.prototype.startStop = function(trigger) {
    this.count += 1;
    $("#counter_edit")[0].value = this.count;
    var time = pgUtil.getCurrentTime();
    var eventData = {count: this.count};
    if(trigger)
        data.trigger = trigger;
    pg.addNewEvents({page: "counter", type: "count", start: time, data: eventData}, true);
    syncSoon();
    return false; // prevent click from being handled elsewhere
};

counter.prototype.reset = function() {
    var data = this.getPageData();
    this.count += 1;
    if(data.countTarget != 0) {
        var correct = (this.count == data.countTarget);
        pgAudio.giveFeedback(correct);
    }
    var time = pgUtil.getCurrentTime();
    var eventData = {count: this.count, target: data.countTarget};
    pg.addNewEvents({page: "counter", type: "reset", start: time, data: eventData}, true); 
    this.count = 0;
    $("#counter_edit")[0].value = this.count;
    syncSoon();
    return false; // prevent click from being handled elsewhere
};


UI.counter = new counter();
//# sourceURL=counter.js
