

var pgPosition = {
    bgGeo:            null,
    previousPosition: new Array(),
    running:          false,
    callback:         null,
    timeout:          null,
    warned:           false,

    opts: {
        // PG configuration
        powerSaving:       true,

        // Geolocation config
        desiredAccuracy:   5,
        stationaryRadius:  10,
        distanceFilter:    15,
        maxLocations:      10000,
        debug:             false,
        stopOnTerminate:   false,
        //    url: 'http://192.168.81.15:3000/locations',
        //syncUrl: 'http://192.168.81.15:3000/sync',
        //syncThreshold: 100,
        //httpHeaders: {
        //    'X-FOO': 'bar'
        //},
        
        // for Android only, which logs the events to a file if url=="file://*"
        startOnBoot:       false,
        startForeground:   true,
        notificationTitle: 'Psygraph',
        notificationText:  'Tracking location.',
        interval:          10000,
        locationProvider:  0, //backgroundGeolocation.provider.ANDROID_DISTANCE_FILTER_PROVIDER,
        // ANDROID_ACTIVITY_PROVIDER options
        fastestInterval:      5000,
        activitiesInterval:   5000,
        stopOnStillActivity:  true,

        // for IOS only
        activityType:            'Other', //'AutomotiveNavigation'
        saveBatteryOnBackground: false,
    },

    init: function() {
        if(!pgUtil.isWebBrowser() && !pgPosition.bgGeo &&
           typeof(backgroundGeolocation)!="undefined") { // 
            pgPosition.bgGeo = backgroundGeolocation; //window.plugins.backgroundGeoLocation;
            //pgPosition.opts.locationProvider = backgroundGeolocation.provider.ANDROID_DISTANCE_FILTER_PROVIDER;
        }
    },
    
    cordovaOpts: {
        maximumAge: 6000,
        timeout: 3000,
        enableHighAccuracy: true
    },
    
    setCallback: function(cb) {
        pgPosition.callback = cb;
        pgPosition.positionChecker(pgPosition.callback != null);
    },

    positionChecker: function(run, interval) {
        interval = typeof(interval)!="undefined" ? interval : 3000;
        if(run) {
            if(typeof(pgPosition.timeout) != "undefined") {
                showWarn("Ran position checker twice");
                clearInterval(pgPosition.timeout);
            }
            pgPosition.timeout = setInterval(posChecker, interval);
        }
        else {
            if(typeof(pgPosition.timeout) != "undefined") {
                clearInterval(pgPosition.timeout);
                delete(pgPosition.timeout);
            }
        }
        function posChecker() {
            //pgPosition.getPositionData(posCallback);
            pgPosition.getCurrentPosition(posCallback);
            
            function posCallback(data) {
                //var lastDataLength = typeof()!="undefined" ? this.lastDataLength : 0;
                //this.lastDataLength = data.length;
                //if(lastDataLength != this.lastDataLength)
                if(pgPosition.callback)
                    pgPosition.callback(data);
            }
        }
    },

    addToPath: function(position) {
        var lat;
        var lng;
        var alt=0;
        if(typeof(position.coords) != "undefined") {
            if(typeof(position.coords.latitude)!="undefined")
                lat = position.coords.latitude;
            if(typeof(position.coords.longitude)!="undefined")
                lng = position.coords.longitude;
            if(position.coords.altitude)
                alt = position.coords.altitude;
        }
        else {
            if(typeof(position.latitude)!="undefined")
                lat = position.latitude;
            if(typeof(position.longitude)!="undefined")
                lng = position.longitude;
        }
        if(position.altitude)
            alt = position.altitude;
        if(typeof(lat)=="undefined" || typeof(lng)=="undefined") {
            showWarn("Received empty position");
            return;
        }
        pgPosition.previousPosition.push([ pgUtil.getCurrentTime(),
                                           lat, lng, alt ]);
    },

    positionCB: function(bgGeo, position) {
        if(bgGeo) { // && pg.background {
            // ignore position, since there may be an array of values waiting.
            if(pgPosition.callback)
                pgPosition.getPositionData(pgPosition.callback);
            pgPosition.bgGeo.finish();
        }
        else  {
            pgPosition.addToPath(position);
            if(pgPosition.callback)
                pgPosition.callback(pgPosition.previousPosition);
        }
    },
    
    failureCB: function(error) {
        showLog('GeoLocation error');
        if(pgPosition.callback)
            pgPosition.callback("Unknown location");
    },

    runInBG: function() {
        return pgPosition.bgGeo && pgPosition.opts.powerSaving;
    },
    start: function(opts) {
        pgPosition.init();
        pgPosition.positionChecker(false);
        if(pgPosition.running) {
            showError("Position data already being gathered.");
            return;
        }
        if(typeof(opts.restarting)=="undefined")
            pgPosition.previousPosition = new Array();
        //pgPosition.category = pg.category();
        pgPosition.running  = true;

        if(navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(pgPosition.positionCB.bind(this, false), pgPosition.failureCB, pgPosition.cordovaOpts);
        }
        for(i in opts) {
            if(i == "accuracy") {
                // Accuracy is a value from 0 ( accurate) to 10 (most accurate).
                // radius ranges from 2 to 1002 meters
                var radius = (10-opts[i]) * 100 + 2;
                pgPosition.opts.desiredAccuracy  = Math.round(radius/2);
                pgPosition.opts.stationaryRadius = Math.round(radius);
                pgPosition.opts.distanceFilter   = Math.round(radius*2);

                // update interval ranges from 1000 to 61000 ms
                var updateInterval = (10-opts[i]) *6000 + 1000;
                pgPosition.opts.interval           = updateInterval;
                pgPosition.opts.fastestInterval    = updateInterval/2;
                pgPosition.opts.activitiesInterval = updateInterval/2;

                pgPosition.opts.saveBatteryOnBackground = (opts[i] < 5);
             
                // update the Cordova parameters
                pgPosition.cordovaOpts.maximumAge         = updateInterval;
                pgPosition.cordovaOpts.timeout            = updateInterval/2;
                pgPosition.cordovaOpts.enableHighAccuracy = opts[i] > 5;
            }
            else if( i=="powerSaving" ) {
                pgPosition.opts.powerSaving = opts[i];
            }
        }
        if(pgPosition.runInBG()) {
            // xxx do we _need_ to stop and restart?  Or is the service still running?
            if(typeof(opts.restarting)!="undefined")
                pgPosition.bgGeo.stop();
            pgPosition.bgGeo.configure(pgPosition.positionCB.bind(this,true), pgPosition.failureCB, pgPosition.opts);
            pgPosition.bgGeo.start();
        }
        else {
            pgPosition.watchID = navigator.geolocation.watchPosition(pgPosition.positionCB.bind(this,false), pgPosition.failureCB, pgPosition.cordovaOpts);
        }
    },

    update: function(starting, state) {
        if(!starting) {
            var state = {running:     pgPosition.running,
                         opts:        pgPosition.opts,
                         cordovaOpts: pgPosition.cordovaOpts
                        };
            return state;
        }
        if(typeof(state)!="undefined" && state.opts) { //starting
            if(state.running) {
                pgPosition.opts        = state.opts;
                pgPosition.cordovaOpts = state.cordovaOpts;
            }
            pgPosition.getPositionData(cb.bind(this,state.running));
        }
        function cb(running, data) {
            if(running)
                pgPosition.start({restarting: true});
        }
    },
    stop: function() {
        pgPosition.positionChecker(true);
        if(pgPosition.runInBG()) {
            pgPosition.bgGeo.stop();
        }
        else {
            navigator.geolocation.clearWatch(pgPosition.watchID);
            pgPosition.watchID = null;
        }
        pgPosition.running = false;
    },

    getCurrentPosition : function(callback) {
        // if we are running, we should just return the last collected point
        if(pgPosition.running) {
            var len = pgPosition.previousPosition.length;
            if(len) {
                callback( [pgPosition.previousPosition[len-1]] );
                return;
            }
        }
        if(navigator.geolocation) {
            //var options = { enableHighAccuracy: true, maximumAge: 500, timeout: 6000 };
            //var watchID = navigator.geolocation.watchPosition(successCB, failCB, options);
            //var timeout = setTimeout( function() { navigator.geolocation.clearWatch( watchID ); }, 6000 );
            navigator.geolocation.getCurrentPosition(successCB, failCB, pgPosition.cordovaOpts);
        }
        else
            callback();
        function successCB(pos) {
            point = [ pos.timestamp,
                      pos.coords.latitude,
                      pos.coords.longitude,
                      pos.coords.altitude
                    ];
            if(point[3]==null)
                point[3]=0;
            callback([point]);
        }
        function failCB(err) {
            if(!pgPosition.warned) {
                showWarn("Could not get the current location: " + err.message + ". Are GPS and/or cell networks available?");
                pgPosition.warned = true;
            }
            callback();
        }
    },
    /*
    loadPositionData: function(callback) {
        pgPosition.init();
        pgFile.init(gotDir);
        function gotDir() {
            var filename = pgPosition.opts.url.substring(7); // we assume file://
            pgFile.readFile(filename, gotFile, false);
        }
        function gotFile(success, jdata) {
            if(success) {
                try {
                    var data = [];
                    if(jdata.length) {
                        if(jdata.length &&
                           (jdata=="[" ||
                            jdata.startsWith("[[") && !jdata.endsWith("]]")) )
                            jdata += "]"; // they were not finished writing the array
                        data = JSON.parse(jdata);
                        var lastTime = 0;
                        if(pgPosition.previousPosition.length)
                            lastTime = pgPosition.previousPosition[pgPosition.previousPosition.length-1][0];
                        for(var i=0; i<data.length; i++) {
                            if(data[i][0] > lastTime) {
                                if(data[i][3] == null)
                                    data[i][3] = 0;
                                pgPosition.previousPosition.push(data[i]);
                            }
                        }
                    }
                }
                catch(err) {
                    showError(err);
                }
            }
            callback(success);
        }
    },
    */
    getPositionData: function(callback) {
        if(pgPosition.runInBG()) {
            pgPosition.bgGeo.getValidLocations(cb);
            //pgPosition.loadPositionData(cb);
            //function cb(success) {
            //    callback(pgPosition.previousPosition);
            //}
        }
        else {
            callback(pgPosition.previousPosition);
        }
        function cb (locations) {
            // only add locations which occur after the existing path
            var len      = pgPosition.previousPosition.length;
            var lastTime = pgPosition.previousPosition[len-1][0];
            for(var position in locations) {
                var loc = locations[position];
                pgPosition.bgGeo.deleteLocation(loc.id);
                if(len && loc.time <= lastTime) {
                    continue;
                }
                pgPosition.addToPath(loc);
            }
            callback(pgPosition.previousPosition);
        }
    },
    
    getPathLength: function(path) {
        var sum = 0;
        for(var i=1; i<path.length; i++) {
            var a = {lat: path[i-1][1], lng: path[i-1][2]};
            var b = {lat: path[i][1], lng: path[i][2]};
            sum += calculate_distance(a,b);
        }
        return sum;

        var units = "english"; // miles, not km
        function calculate_distance(a, b) {
            var R = (units == "english") ? 3958.7558 : 6371;

            var dLat = (a.lat - b.lat) * Math.PI / 180;
            var dLon = (a.lng - b.lng) * Math.PI / 180;
            var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(a.lat * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2);
            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            return R * c;
        }
    }
};
